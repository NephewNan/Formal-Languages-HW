#!/usr/bin/env python3
# # # # # # # # # # # # # # # # # # # # # # # # # # # # #
#  Framework for Automaten en Formele Talen             #
#  Written by: Robin Visser & Tristan Laan              #
#  based on work by: Bas van den Heuvel & Daan de Graaf #
#                                                       #
#  This work is licensed under a Creative Commons       #
#  “Attribution-ShareAlike 4.0 International”  license. #
# # # # # # # # # # # # # # # # # # # # # # # # # # # # #

from TM import TM
from pathlib import Path


def extract_input(trace: str,
                  trace_tokenized: list[str] | None = None) -> str:
    """
    Determines (and returns) the input string given to the TM that caused it to
    perform the computation that produced the given trace.

    In principle you don't need to use trace_tokenized, but you can assume both
    trace, and trace_tokenized are provided during grading.

    trace:            a single TM trace (as a string with spaces).
    trace_tokenized:  optional, the same trace tokenized (as a list of tokens).
    returns:          the input (as a string without spaces)
    """

    ### Your code + explanation here
    # Characters for left endmarker and BLANK: ⊢ , ⊔

    return None


def extract_output(trace: str,
                   trace_tokenized: list[str] | None = None) -> str:
    """
    Determines (and returns) the tape output produced by the TM when performing
    the computation that produced the given trace. The ouput is the longest
    possible string _after_ the left endmarker that does not end in
    a BLANK ('⊔').

    In principle you don't need to use trace_tokenized, but you can assume both
    trace, and trace_tokenized are provided during grading.

    trace:            a single TM trace (as a string with spaces).
    trace_tokenized:  optional, the same trace tokenized (as a list of tokens).
    returns:          the output (as a string without spaces)
    """

    ### Your code + explanation here
    # Characters for left endmarker and BLANK: ⊢ , ⊔

    return None


def reverse_manually(verbose: bool = True) -> TM:
    """
    The original TM was designed to: <your answer here>

    The algorithm used by the original TM works as follows: <your answer here>

    verbose: Whether verbose mode of TM is enabled

    returns: A TM object of no more than 20 states, capable of reproducing the
             traces given by the assignment.
    """

    ### Your reverse-engineered TM + explanation here

    Q = ['t', 'r']
    Sigma = ['0', '1', '|']
    Gamma = ['0', '1', '|', '⊔', '⊢']
    delta = []
    s = ''
    t = 't'
    r = 'r'

    tm = TM(Q, Sigma, Gamma, delta, s, t, r, verbose)

    return tm


def reverse_generic(traces: list[str],
                    traces_tokenized: list[list[str]] | None = None,
                    verbose: bool = True) -> TM:
    """
    Recreates (reverse-engineers) a TM which behaves identically to the TM that
    produced the supplied list of traces. Note: 'behaves identically' implies
    that the recreated TM must produce (given the same input) the exact same
    execution traces as the original.

    In principle you don't need to use trace_tokenized, but you can assume both
    trace, and trace_tokenized are provided during grading.

    traces:           a list of traces produced by the original TM.
    traces_tokenized: optional, tokenized versions of the original traces.
    returns:          a TM object capable of reproducing the traces given
                      the same input.
    """

    ### Your code + explanation here

    Q = ['t', 'r']
    Sigma = []
    Gamma = ['⊔', '⊢']
    delta = []
    s = ''
    t = 't'
    r = 'r'

    tm = TM(Q, Sigma, Gamma, delta, s, t, r, verbose)

    return tm


def main(path_traces: Path | None = None,
         path_tokenized: Path | None = None,
         verbose: bool = True) -> None:
    """
    Area to test different parts of your implementation.

    The present code is just an example, feel free to modify at will.
    While it is strongly recommended to write some tests here, the code
    produced will not directly influence your grade.
    """

    """ Input/output extraction """
    test_traces = [
                    # Test trace 1
                    '- ⊢ + ⊢ > '
                    '- 0 + 1 > '
                    '- 0 + 1 < '
                    '- 1 + ⊔ > '
                    '- 1 + ⊔ > '
                    '- ⊔ + a >',
                    # Test trace 2
                    '- ⊢ + ⊢ > '
                    '- a + c < '
                    '- ⊢ + ⊢ > '
                    '- c + ⊔ > '
                    '- b + ⊔ < '
                    '- ⊔ + ⊢ > '
                    '- ⊔ + ⊔ > '
                    '- ⊔ + ⊢ >'
                  ]

    test_traces_tokenized = [
                             # Test trace 1
                             ['READ', 'LEM',    'WRITE', 'LEM',    'MRIGHT',
                              'READ', 'SYMBOL', 'WRITE', 'SYMBOL', 'MRIGHT',
                              'READ', 'SYMBOL', 'WRITE', 'SYMBOL', 'MLEFT',
                              'READ', 'SYMBOL', 'WRITE', 'BLANK',  'MRIGHT',
                              'READ', 'SYMBOL', 'WRITE', 'BLANK',  'MRIGHT',
                              'READ', 'BLANK',  'WRITE', 'SYMBOL', 'MRIGHT'],
                             # Test trace 2
                             ['READ', 'LEM',    'WRITE', 'LEM',    'MRIGHT',
                              'READ', 'SYMBOL', 'WRITE', 'SYMBOL', 'MLEFT',
                              'READ', 'LEM',    'WRITE', 'LEM',    'MRIGHT',
                              'READ', 'SYMBOL', 'WRITE', 'BLANK',  'MRIGHT',
                              'READ', 'SYMBOL', 'WRITE', 'BLANK',  'MLEFT',
                              'READ', 'BLANK',  'WRITE', 'LEM',    'MRIGHT',
                              'READ', 'BLANK',  'WRITE', 'BLANK',  'MRIGHT',
                              'READ', 'BLANK',  'WRITE', 'LEM',    'MRIGHT']
                            ]

    correct_inputs = [
                      '00',
                      'ab'
                     ]

    correct_outputs = [
                       '⊔⊔a',
                       '⊢⊔⊢'
                      ]

    # Only test input/output extraction functions that do not return "None"
    for idx in range(len(test_traces)):
        feedback = ""
        extracted_input = extract_input(test_traces[idx],
                                        test_traces_tokenized[idx])
        if extracted_input is not None and \
           extracted_input != correct_inputs[idx]:
            feedback += f"\nextracted input: '{extracted_input}' " \
                        f"incorrect! (expected: '{correct_inputs[idx]}')"
        extracted_output = extract_output(test_traces[idx],
                                          test_traces_tokenized[idx])
        if extracted_output is not None and \
           extracted_output != correct_outputs[idx]:
            feedback += f"\nextracted output: '{extracted_output}' " \
                        f"incorrect! (expected: '{correct_outputs[idx]}')"
        if feedback:
            feedback = test_traces[idx] + feedback
            print(feedback)

    """ Reverse engineering """
    # Read execution traces (as strings with spaces), if available.
    traces = None
    if path_traces:
        with path_traces.open(encoding='utf-8') as f:
            traces = [trace for trace in [line.rstrip('\n') for line in f]]

    # Read tokenized traces (as lists of tokens, excluding 'SPACE'),
    # if available.
    traces_tokenized = None
    if path_tokenized:
        with path_tokenized.open(encoding='utf-8') as f:
            traces_tokenized = [trace.split() for trace in [line.rstrip('\n')
                                for line in f]]

    # Scratchpad, try to Reverse engineer the TM using the framework!

    # Examples:
    # if traces:
    #     print(traces[0])
    #     print(extract_input(traces[0]))
    #     print(extract_output(traces[0]))
    #     TM.visualize(extract_input(traces[0]), traces[0])

    # Validate your solution by checking if it produces the original traces
    # given the original inputs...

    # tm = reverse_manually(verbose)
    # if traces:
    #     for trace in traces:
    #         tm.set_input(extract_input(trace))
    #         tm.transition_all()
    #         produced_trace = tm.get_execution_trace()
    #         if trace != produced_trace:
    #             print("TM produced an incorrect trace!")
    #             print(f"original: {trace}")
    #             print(f"TM:       {produced_trace}")
    #             input("Press enter to continue...")


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='Reverse engineers a TM')
    parser.add_argument('-n', '--no-verbose', action='store_true',
                        help='disable verbose mode of TM')
    parser.add_argument('traces', type=Path, nargs='?',
                        help='file containing traces (optional)')
    parser.add_argument('tokenized_traces', type=Path, nargs='?',
                        help='file containing tokenized traces (optional)')
    args = parser.parse_args()
    main(args.traces, args.tokenized_traces, not args.no_verbose)
